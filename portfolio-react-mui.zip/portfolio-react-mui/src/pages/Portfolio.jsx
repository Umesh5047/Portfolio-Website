import React from 'react'
import Box from '@mui/material/Box'
import Divider from '@mui/material/Divider'
import Navbar from '../components/Navbar'
import { IntroSection, SkillsSection, ProjectsSection, ContactSection } from '../components/Sections'

export default function Portfolio() {
  return (
    <Box>
      <Navbar />
      <IntroSection />
      <Divider />
      <SkillsSection />
      <Divider />
      <ProjectsSection />
      <Divider />
      <ContactSection />
    </Box>
  )
}
