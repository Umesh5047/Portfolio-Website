import React, { useReducer, useState } from 'react'
import Container from '@mui/material/Container'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid2'
import Chip from '@mui/material/Chip'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardActions from '@mui/material/CardActions'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'
import Link from '@mui/material/Link'
import Avatar from '@mui/material/Avatar'

const skills = [
  'React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'Git', 'Docker'
]

const projects = [
  {
    title: 'Project One',
    description: 'A cool project that demonstrates my skills with React and APIs.',
    image: 'https://picsum.photos/seed/p1/600/400',
    repo: 'https://github.com/yourname/project-one',
    demo: 'https://example.com/project-one'
  },
  {
    title: 'Project Two',
    description: 'An elegant UI built with Material UI and React Router.',
    image: 'https://picsum.photos/seed/p2/600/400',
    repo: 'https://github.com/yourname/project-two',
    demo: 'https://example.com/project-two'
  },
  {
    title: 'Project Three',
    description: 'Full-stack application using Node.js and a cloud database.',
    image: 'https://picsum.photos/seed/p3/600/400',
    repo: 'https://github.com/yourname/project-three',
    demo: 'https://example.com/project-three'
  }
]

function formReducer(state, action) {
  switch (action.type) {
    case 'SET':
      return { ...state, [action.field]: action.value }
    case 'RESET':
      return { name: '', email: '', message: '' }
    default:
      return state
  }
}

export function IntroSection() {
  return (
    <Container sx={{ py: 8 }} id="intro">
      <Grid container spacing={4} alignItems="center">
        <Grid size={{ xs: 12, md: 4 }}>
          <Avatar
            src="https://picsum.photos/seed/me/400/400"
            alt="Profile"
            sx={{ width: 200, height: 200, mx: 'auto' }}
          />
        </Grid>
        <Grid size={{ xs: 12, md: 8 }}>
          <Typography variant="h3" gutterBottom>John Doe</Typography>
          <Typography variant="h6" gutterBottom>Frontend Developer</Typography>
          <Typography paragraph>
            I build modern, responsive web apps with React, TypeScript, and delightful UX details.
            I love translating design mockups into pixel-perfect, accessible interfaces.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button variant="contained" component={Link} href="/resume.pdf" target="_blank" rel="noopener">Resume</Button>
            <Button component={Link} href="https://github.com/yourname" target="_blank" rel="noopener">GitHub</Button>
            <Button component={Link} href="https://www.linkedin.com" target="_blank" rel="noopener">LinkedIn</Button>
            <Button component={Link} href="#contact">Contact</Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  )
}

export function SkillsSection() {
  return (
    <Container sx={{ py: 8 }} id="skills">
      <Typography variant="h4" gutterBottom>Skills</Typography>
      <Box sx={{ display: 'flex', gap: 1.2, flexWrap: 'wrap' }}>
        {skills.map((s) => (
          <Chip key={s} label={s} />
        ))}
      </Box>
    </Container>
  )
}

export function ProjectsSection() {
  return (
    <Container sx={{ py: 8 }} id="projects">
      <Typography variant="h4" gutterBottom>Projects</Typography>
      <Grid container spacing={3}>
        {projects.map((p) => (
          <Grid key={p.title} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <img src={p.image} alt={p.title} style={{ width: '100%', height: 180, objectFit: 'cover' }} />
              <CardContent>
                <Typography variant="h6">{p.title}</Typography>
                <Typography variant="body2" color="text.secondary">{p.description}</Typography>
              </CardContent>
              <CardActions sx={{ mt: 'auto' }}>
                <Button size="small" href={p.demo} target="_blank" rel="noopener">Live Demo</Button>
                <Button size="small" href={p.repo} target="_blank" rel="noopener">Repo</Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  )
}

export function ContactSection() {
  const [state, dispatch] = useReducer(formReducer, { name: '', email: '', message: '' })
  const [status, setStatus] = useState(null)

  const onChange = (e) => {
    dispatch({ type: 'SET', field: e.target.name, value: e.target.value })
  }

  const validate = () => {
    if (!state.name.trim()) return 'Name is required.'
    if (!state.email.match(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)) return 'A valid email is required.'
    if (state.message.trim().length < 10) return 'Message should be at least 10 characters.'
    return null
  }

  const onSubmit = (e) => {
    e.preventDefault()
    const error = validate()
    if (error) { setStatus({ type: 'error', message: error }); return }
    // Simulate submit
    console.log('Contact message:', state)
    setStatus({ type: 'success', message: 'Thanks! Your message has been sent.' })
    dispatch({ type: 'RESET' })
  }

  return (
    <Container sx={{ py: 8 }} id="contact">
      <Typography variant="h4" gutterBottom>Contact</Typography>
      <Box component="form" onSubmit={onSubmit} sx={{ display: 'grid', gap: 2, maxWidth: 600 }}>
        <TextField name="name" label="Name" value={state.name} onChange={onChange} required />
        <TextField name="email" label="Email" value={state.email} onChange={onChange} required />
        <TextField name="message" label="Message" value={state.message} onChange={onChange} multiline rows={4} required />
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <Button type="submit" variant="contained">Send</Button>
          {status && (
            <Typography variant="body2" color={status.type === 'error' ? 'error' : 'primary'}>
              {status.message}
            </Typography>
          )}
        </Box>
      </Box>
    </Container>
  )
}
